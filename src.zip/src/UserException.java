public class UserException extends Exception
{
   public UserException(String errorMessage)
   {
      super(errorMessage);
   }
}

class IncorrectUserInput extends UserException
{
   public IncorrectUserInput(String errorMessage)
   {
      super(errorMessage);
   }
}

class FibonacciArgumentOutOfRange extends UserException
{
   public FibonacciArgumentOutOfRange(String errorMessage)
   {
      super(errorMessage);
   }
}

class IncorrectArgumentFiles extends UserException
{
   public IncorrectArgumentFiles(String errorMessage)
   {
      super(errorMessage);
   }
}

class InputOutputFileOverwriteException extends UserException
{
   public InputOutputFileOverwriteException(String errorMessage)
   {
      super(errorMessage);
   }
}

class OverwriteDeclinedException extends UserException
{
   public OverwriteDeclinedException(String message)
   {
      super(message);
   }
}
