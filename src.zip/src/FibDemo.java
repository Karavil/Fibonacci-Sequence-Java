import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class FibDemo
{

   private final static int GRACEFUL_EXIT_CODE = 1;

   public static void main(String[] args)
   {
      validateArgumentFiles(args);

      final int INPUT_FILE_INDEX = 0;
      final int OUTPUT_FILE_INDEX = 1;

      final int MIN_START_INDEX = 1;
      final int MAX_START_INDEX = 13;
      final int MIN_RUN_COUNT = 1;
      final int MAX_RUN_COUNT = 35;

      int[] parsedInputArguments = parseInputFile(args[INPUT_FILE_INDEX],
                                                  MIN_START_INDEX,
                                                  MAX_START_INDEX,
                                                  MIN_RUN_COUNT, MAX_RUN_COUNT);

      final int START_VALUE_INDEX = 0;
      final int RUN_COUNT_INDEX = 1;

      final int startValue = parsedInputArguments[START_VALUE_INDEX];
      final int runCount = parsedInputArguments[RUN_COUNT_INDEX];

      Sequence iterativeFibonacci = new LoopFibSequence();
      Sequence slowRecursiveFibonacci = new FibSequence();
      Sequence fastRecursiveFibonacci = new FastFibSequence();


      String currentSequenceName = "Normal Recursive:";
      String slowRecursiveOutput = generateFibonacciOutput(
              slowRecursiveFibonacci, runCount, startValue,
              currentSequenceName);
      System.out.print(slowRecursiveOutput);

      currentSequenceName = "Iterative:";
      String iterativeOutput = generateFibonacciOutput(iterativeFibonacci,
                                                       runCount, startValue,
                                                       currentSequenceName);
      System.out.print(iterativeOutput);

      currentSequenceName = "Fast Recursive:";
      String fastRecursiveOutput = generateFibonacciOutput(
              fastRecursiveFibonacci, runCount, startValue,
              currentSequenceName);
      System.out.print(fastRecursiveOutput);

      String combinedFibonacciOutput =
              slowRecursiveOutput + "\n" + iterativeOutput + "\n" +
              fastRecursiveOutput;
      writeToOutputFile(combinedFibonacciOutput, args[OUTPUT_FILE_INDEX]);

   }

   private static void validateArgumentFiles(String[] programArguments)
   {
      final int INPUT_FILE_INDEX = 0;
      final int OUTPUT_FILE_INDEX = 1;
      final int REQUIRED_ARGUMENT_COUNT = 2;

      try
      {
         if (programArguments.length != REQUIRED_ARGUMENT_COUNT)
         {
            final int NO_ARGUMENTS = 0;
            if (programArguments.length == NO_ARGUMENTS)
            {
               throw new IncorrectArgumentFiles(
                       "\nERROR: No file arguments found." +
                       " Include your input and output " +
                       "file while executing this program. Example: java " +
                       "FibDemo infile outfile");
            }

            throw new IncorrectArgumentFiles(
                    "\nERROR: Please make sure you " + "only have 2 arguments" +
                    ". Example: java FibDemo infile " + "outfile");
         }

         String inputFileName = programArguments[INPUT_FILE_INDEX];
         String outputFileName = programArguments[OUTPUT_FILE_INDEX];
         boolean inputFound = false;
         boolean outputFound = false;
         File input = null;
         File output = null;


         inputFound = searchForFile(inputFileName);
         if (!inputFound)
         {
            throw new FileNotFoundException(
                    "ERROR: Your input file was not found. Please" +
                    " make sure your input file is in the same " +
                    "directory as the FibDemo class file.");
         }
         else
         {
            try
            {
               input = generateFileObject(inputFileName);
            }
            catch (IOException e)
            {
               System.out.println("ERROR: IOException occurred while creating" +
                                  " input file object.");
               e.printStackTrace();
               System.exit(GRACEFUL_EXIT_CODE);
            }
         }


         outputFound = searchForFile(outputFileName);
         if (outputFound)
         {
            System.out.println("\nAn output file already exists, would you " +
                               "like to override this file? [Enter Y for " +
                               "yes] [Enter N for no]\nEntering 'N' will " +
                               "terminate the program.");

            boolean overrideOutputFile = getUserOverrideDecision();
            if (!overrideOutputFile)
            {
               throw new OverwriteDeclinedException(
                       "Output override has been declined. Exiting program.");
            }
            else
            {
               System.out.println("Override allowed. Your file contents " +
                                  "will be overwritten.");
               output = generateFileObject(programArguments[OUTPUT_FILE_INDEX]);
            }
         }
         else
         {
            try
            {
               createFileInDirectory(outputFileName);
               output = generateFileObject(outputFileName);
            }
            catch (FileNotFoundException e)
            {
               throw new FileNotFoundException("ERROR: Output file was not " +
                                               "found after creating it. " +
                                               "This should not happen... " +
                                               "Exiting program.");
            }
            catch (IOException e)
            {
               System.out.println("ERROR: An IOException occurred while " +
                                  "creating output file. Exiting program.");
               e.printStackTrace();
               System.exit(GRACEFUL_EXIT_CODE);
            }
         }


         String inputPath = input.getAbsolutePath();
         String outputPath = output.getAbsolutePath();

         if (inputPath.equals(outputPath))
         {
            throw new InputOutputFileOverwriteException(
                    "\nERROR: Your input " + "and output files " +
                    "point to the same " + "file. Please make " +
                    "sure your input and " + "output files are not" +
                    " the same file.");
         }
      }
      catch (IncorrectArgumentFiles e)
      {
         System.out.println(e.getMessage());
         System.exit(GRACEFUL_EXIT_CODE);
      }
      catch (InputOutputFileOverwriteException e)
      {
         System.out.println(e.getMessage());
         System.exit(GRACEFUL_EXIT_CODE);
      }
      catch (OverwriteDeclinedException e)
      {
         System.out.println(e.getMessage());
         System.exit(GRACEFUL_EXIT_CODE);
      }
      catch (FileNotFoundException e)
      {
         System.out.println(e.getMessage());
         System.exit(GRACEFUL_EXIT_CODE);
      }
   }

   private static int[] parseInputFile(String fileName, int minStart,
                                       int maxStart, int minRuns, int maxRuns)
   {

      final int GRACEFUL_EXIT_CODE = 1;
      Scanner inputReader = null;

      try
      {
         File inputFile = null;
         try
         {
            inputFile = generateFileObject(fileName);
         }
         catch (IOException e)
         {
            System.out.println("ERROR: An IOException occurred while reading " +
                               "input file.");
            e.printStackTrace();
         }

         inputReader = new Scanner(inputFile);

         int lineCounter = 0;
         String argumentsLine = "";

         while (inputReader.hasNextLine())
         {
            argumentsLine = inputReader.nextLine();
            lineCounter++;
         }

         final int REQUIRED_ARGUMENT_LINES = 1;
         final int NO_ARGUMENT_LINES = 0;

         if (lineCounter != REQUIRED_ARGUMENT_LINES)
         {
            if (lineCounter == NO_ARGUMENT_LINES)
            {
               throw new IncorrectUserInput(
                       "\nERROR: Your input file is " + "empty," +
                       " please make sure to include fibonacci program " +
                       "arguments  in your input file.");
            }

            throw new IncorrectUserInput(
                    "\nERROR: Please make sure to only use 1 line to " +
                    "submit program arguments. Example: 2 & " +
                    "13 <--- this will print 13 fibonacci " +
                    "values after the the second fibonacci number, inclusively." +
                    "The first argument can range from [1-13] and the second " +
                    "argument can range from [1-35], both exclusively. " +
                    "(Blank lines are not allowed.)");
         }

         String[] arguments = argumentsLine.split(" ");

         final int REQUIRED_ARGUMENTS = 3;
         if (arguments.length != REQUIRED_ARGUMENTS)
         {
            throw new IncorrectUserInput(
                    "\nERROR: Please make sure to only have 2 arguments" +
                    " and a '&' character in your input file. Example: 2 & " +
                    "13 <--- this will print 13 fibonacci " +
                    "values after the the second fibonacci number, inclusively." +
                    "The first argument can range from [1-13] and the second " +
                    "argument can range from [1-35], both exclusively. " +
                    "(Blank lines are not allowed.)");
         }

         int[] parsedArguments;
         parsedArguments = parseFibonacciArguments(arguments, minStart,
                                                   maxStart, minRuns, maxRuns);

         return parsedArguments;
      }
      catch (FileNotFoundException e)
      {
         System.out.println("Unable to find file '" + fileName + "'. Please " +
                            "make sure the file you are referencing is in the" +
                            " same directory as the FibDemo class.");
         System.exit(GRACEFUL_EXIT_CODE);
      }
      catch (IncorrectUserInput e)
      {
         System.out.println(e.getMessage());
         System.exit(GRACEFUL_EXIT_CODE);
      }
      catch (FibonacciArgumentOutOfRange e)
      {
         System.out.println(e.getMessage());
         System.exit(GRACEFUL_EXIT_CODE);
      }
      finally
      {
         if (inputReader != null)
         {
            inputReader.close();
         }
      }

      return null;
   }

   private static int[] parseFibonacciArguments(String[] arguments,
                                                int minStart, int maxStart,
                                                int minRuns, int maxRuns)
           throws FibonacciArgumentOutOfRange, IncorrectUserInput
   {

      final int START_VALUE_INDEX = 0;
      final int AND_CHARACTER_INDEX = 1;
      final int RUN_COUNT_INDEX = 2;

      try
      {
         int startValue = Integer.parseInt(arguments[START_VALUE_INDEX]);
         int valueCount = Integer.parseInt(arguments[RUN_COUNT_INDEX]);
         if (!(arguments[AND_CHARACTER_INDEX].equals("&")))
         {
            throw new IncorrectUserInput(
                    "Please make sure to only have 2 arguments" +
                    "and a & character in your input file. Example: 2 & " +
                    "13 <--- this will print 13 fibonacci " +
                    "values after the the second fibonacci number, inclusively." +
                    "The first argument can range from [1-13] and the second " +
                    "argument can range from [1-35], both exclusively. " +
                    "(Blank lines are not allowed.)\n");
         }

         if (startValue < minStart || startValue > maxStart)
         {
            throw new FibonacciArgumentOutOfRange(
                    "\nERROR: Your first argument, which declares the " +
                    "start index is out of range. Please input a value " +
                    "between 1 and 13, inclusive.\n");
         }

         if (valueCount < minRuns || valueCount > maxRuns)
         {
            throw new FibonacciArgumentOutOfRange(
                    "\nERROR: Your second argument, which declares the " +
                    "amount of values needed after the start value, " +
                    "inclusively, is out of range. Please input a value " +
                    "between 1 and 35, inclusive.\n");
         }

         int[] fibonacciArguments = {startValue, valueCount};
         return fibonacciArguments;
      }
      catch (NumberFormatException e)
      {
         throw new IncorrectUserInput(
                 "\nERROR: Please make sure that your 2 arguments" +
                 "in your input file are integers. Example: 2 & " +
                 "13 <--- this will print 13 fibonacci " +
                 "values after the the second fibonacci number, inclusively." +
                 "The first argument can range from [1-13] and the second " +
                 "argument can range from [1-35], both exclusively. " +
                 "(Blank lines are not allowed.)\n");
      }
   }


   private static boolean getUserOverrideDecision()
   {
      Scanner userInput = new Scanner(System.in);
      final int argumentLength = 1;
      String yesDecision = "Y";
      String noDecision = "N";

      String userDecision = "";
      while (userInput.hasNextLine())
      {
         userDecision = userInput.nextLine();
         if (userDecision.length() == argumentLength)
         {
            if (userDecision.equals(yesDecision))
            {
               return true;
            }
            else if (userDecision.equals(noDecision))
            {
               return false;
            }
         }
         System.out.println(
                 "Please make sure input is either Y or N, try again: ");
      }

      return false;
   }

   private static File generateFileObject(String fileName)
           throws FileNotFoundException
   {
      File returnFile = new File(fileName);

      if (!(returnFile.exists()))
      {
         throw new FileNotFoundException();
      }

      return returnFile;
   }

   private static void createFileInDirectory(String fileName) throws IOException
   {
      File returnFile = new File(fileName);
      if (!(returnFile.exists()))
      {
         try
         {
            returnFile.createNewFile();
         }
         catch (IOException e)
         {
            throw e;
         }
      }
   }

   private static boolean searchForFile(String fileName)
   {
      File returnFile = new File(fileName);

      if (!(returnFile.exists()))
      {
         return false;
      }

      return true;
   }

   private static void writeToOutputFile(String data, String outputFile)
   {
      FileWriter outputWriter = null;
      try
      {
         File output = generateFileObject(outputFile);
         outputWriter = new FileWriter(output);
         outputWriter.write(data);
      }
      catch (FileNotFoundException e)
      {
         System.out.println("\nERROR: Output file not found. Cannot write to " +
                            "output file");
         e.printStackTrace();
         System.exit(GRACEFUL_EXIT_CODE);
      }
      catch (IOException e)
      {
         System.out.println(
                 "\nERROR: Encountered an IOException while writing to " +
                 "output file. Exiting program");
         e.printStackTrace();
         System.exit(GRACEFUL_EXIT_CODE);

      }
      finally
      {
         try
         {
            if (outputWriter != null)
            {
               outputWriter.close();
            }
         }
         catch (IOException e)
         {
            System.out.println(
                    "\nERROR: Exception occurred while closing " + "file" +
                    " " + "writer.");
            e.printStackTrace();
            System.exit(GRACEFUL_EXIT_CODE);
         }
      }

   }

   private static String generateFibonacciOutput(Sequence sequenceInput,
                                                 int runCount, int startIndex,
                                                 String sequenceName)
   {
      long startTime = System.nanoTime();
      ArrayList<Integer> sequenceHistory = new ArrayList<Integer>();
      ArrayList<String> overflowHistory = new ArrayList<String>();
      int integerOverflowCounter = 0;

      int sequenceRunner = 1;
      int sequenceCounter = 0;
      while (sequenceCounter < runCount)
      {
         try
         {
            int sequenceValue = sequenceInput.next();
            if (sequenceRunner >= startIndex)
            {
               sequenceHistory.add(sequenceValue);
               sequenceCounter++;
            }
            sequenceRunner++;
         }
         catch (FibonacciIntegerOverflow e)
         {
            if (sequenceRunner >= startIndex)
            {
               String overflowString = e.getOverflowAsString();
               String digitsToAsterisk = convertStringToAsterisk(
                       overflowString);
               overflowHistory.add(digitsToAsterisk);
               integerOverflowCounter++;
               sequenceCounter++;
            }
            sequenceRunner++;
         }
         catch (FibonacciLongOverflow e)
         {
            System.out.println("\nERROR: Long overflow reached, cannot " +
                               "calculate any more than " + sequenceRunner +
                               " values. [User requested " + runCount +
                               " values.]\n");
            sequenceCounter = runCount;
         }
      }

      long endTime = System.nanoTime();
      final int OVERFLOW_ZERO_CHECK = 0;
      String output = "";

      long runtimeNanoseconds = (endTime - startTime);
      output += "\n" + sequenceName + "\n" +
                generateFibonacciSquare(sequenceHistory, overflowHistory,
                                        runtimeNanoseconds);

      if (integerOverflowCounter > OVERFLOW_ZERO_CHECK)
      {
         output += "ALERT: " + integerOverflowCounter + " integer " +
                   "overflow value(s) were generated in this fibonacci " +
                   "sequence. These values have their digits replaced with " +
                   "asterisks '*' in the output square.\n";
      }

      return output;
   }

   private static String generateFibonacciSquare(
           ArrayList<Integer> sequenceArray, ArrayList<String> overflowHistory,
           long runLengthNanoseconds)
   {
      int rows = 0;
      int columns = 0;
      int valueCount = sequenceArray.size() + overflowHistory.size();


      rows = (int) Math.ceil(Math.sqrt(sequenceArray.size()));
      columns = (int) Math.ceil(valueCount / (double) rows);

      final int EXTRA_SPACES = 3;
      final int MAX_FIBONACCI_LENGTH = getMaxFibonacciLength(sequenceArray,
                                                             overflowHistory);
      int dynamicSquareSpacing = MAX_FIBONACCI_LENGTH + EXTRA_SPACES;

      final int NEW_ROW_CHECK = 0;
      final int FIRST_VALUE_CHECK = 0;

      String formattedSquare = "";
      for (int valueCounter = 0; valueCounter < valueCount; valueCounter++)
      {
         if (valueCounter >= sequenceArray.size())
         {
            int updatedCounter = valueCounter - sequenceArray.size();
            //If current row is filled up, move onto second row
            if (valueCounter % columns == NEW_ROW_CHECK &&
                valueCounter != FIRST_VALUE_CHECK)
            {
               formattedSquare += String
                       .format("\n%" + dynamicSquareSpacing + "s",
                               overflowHistory.get(updatedCounter));
            }
            else //If current row is not full, keep printing on same row
            {
               formattedSquare += String
                       .format("%" + dynamicSquareSpacing + "s",
                               overflowHistory.get(updatedCounter));
            }
         }
         else
         {
            //If current row is filled up, move onto second row
            if (valueCounter % columns == NEW_ROW_CHECK &&
                valueCounter != FIRST_VALUE_CHECK)
            {
               formattedSquare += String
                       .format("\n%" + dynamicSquareSpacing + "d",
                               sequenceArray.get(valueCounter));
            }
            else //If current row is not full, keep printing on same row
            {
               formattedSquare += String
                       .format("%" + dynamicSquareSpacing + "d",
                               sequenceArray.get(valueCounter));
            }
         }
      }

      final int NANO_SECOND_TO_SECOND_CONVERSION = 1000000000;
      double runLengthSeconds =
              runLengthNanoseconds / (double) NANO_SECOND_TO_SECOND_CONVERSION;

      formattedSquare += String
              .format("\n\nTime to compute: %,15d " + "nanoseconds," + " " +
                      "%6" + ".4f" + " " + "seconds" + ".\n",
                      runLengthNanoseconds, runLengthSeconds);

      return formattedSquare;

   }

   private static String convertStringToAsterisk(String input)
   {
      String convertedString = "";
      for (int converter = 0; converter < input.length(); converter++)
      {
         convertedString += "*";
      }

      return convertedString;
   }

   private static int getMaxFibonacciLength(ArrayList<Integer> sequenceArray,
                                            ArrayList<String> overflowHistory)
   {
      final int NO_VALUES = 0;
      int maxValueLength = 0;
      if (overflowHistory.size() > NO_VALUES)
      {
         for (String thisOverflow : overflowHistory)
         {
            if (thisOverflow.length() > maxValueLength)
            {
               maxValueLength = thisOverflow.length();
            }
         }
      }
      else if (sequenceArray.size() > NO_VALUES)
      {
         for (int sequenceValue : sequenceArray)
         {
            if (Integer.toString(sequenceValue).length() > maxValueLength)
            {
               maxValueLength = Integer.toString(sequenceValue).length();
            }
         }
      }
      return maxValueLength;
   }
}



