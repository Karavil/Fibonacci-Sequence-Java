public class LoopFibSequence implements Sequence
{
   private final int FIBONACCI_INDEX_START = 0;
   private int fibonacciIndexCounter = FIBONACCI_INDEX_START;
   private final int FIRST_TWO_FIBONACCI_NUMBERS = 1;
   private boolean longOverflowHappened = false;

   /**
    * Returns the next number in the fibonacci Sequence. This method utilizes
    * an iterative method to calculate the next number, which is faster than
    * both recursive methods implemented in the other Fibonacci Sequence
    * calculators.
    * <p>
    * This method will return Fibonacci numbers starting with 1. If the
    * Fibonacci number is greater than the maximum integer, thus resulting in
    * integer overflow, a FibonacciIntegerOverflow exception will be thrown.
    * <p>
    * This exception holds the overflown integer value as a long, which the
    * user can then acquire.
    * <p>
    * If this method reaches a value greater than the maximum long value,
    * thus resulting in long overflow, will throw a FibonacciLongOverflow
    * exception.
    *
    * @return Next integer Fibonacci number
    * @throws FibonacciIntegerOverflow Thrown when integer overflow occurs
    *                                  when calculating the next Fibonacci
    *                                  number. The exception object holds
    *                                  the value of the integer overflow.
    * @throws FibonacciLongOverflow    Thrown when long overflow occurs when
    *                                  calculating the next Fibonacci number.
    **/
   public int next() throws FibonacciIntegerOverflow, FibonacciLongOverflow
   {
      if (longOverflowHappened)
      {
         throw new FibonacciLongOverflow();
      }

      long thisFibonacci = getFibonacci(fibonacciIndexCounter);
      fibonacciIndexCounter++;

      //If less than 0, long overflow happened as it should be increasing.
      final int ZERO_FOR_NEGATIVE_CHECK = 0;
      if (thisFibonacci < ZERO_FOR_NEGATIVE_CHECK)
      {
         longOverflowHappened = true;
         throw new FibonacciLongOverflow();
      }
      else if (thisFibonacci > Integer.MAX_VALUE)
      {
         throw new FibonacciIntegerOverflow(thisFibonacci);
      }

      return (int) thisFibonacci;

   }

   /**
    * Returns the Fibonacci value at the requested index at speeds faster
    * than the efficient recursive methods. This speed is achieved by
    * iteratively calculating them, instead of recursion, thus using less
    * system resources, resulting in a more efficient and faster calculation.
    *
    * The next index value is calculated by adding the 2 previous values, and
    * the first values are known to be {1, 1}. As the first 2 values are
    * known, the next values can be calculated.
    * @param fibonacciIndex
    * @return
    */
   private long getFibonacci(int fibonacciIndex)
   {
      final int FIBONACCI_KNOWN_INDEX_VALUES = 1;
      if (fibonacciIndex <= FIBONACCI_KNOWN_INDEX_VALUES)
      {
         return FIRST_TWO_FIBONACCI_NUMBERS;
      }

      //Store the previous, and new value of the Fibonacci numbers
      long olderFibonacci = FIRST_TWO_FIBONACCI_NUMBERS;
      long oldFibonacci = FIRST_TWO_FIBONACCI_NUMBERS;
      long newFibonacci = 0;

      //Skip the index of the known numbers as its already calculated
      final int INDEX_AFTER_FIRST_TWO_FIBONACCI_NUMBERS = 2;

      for (int fibLoop = INDEX_AFTER_FIRST_TWO_FIBONACCI_NUMBERS;
           fibLoop <= fibonacciIndex; fibLoop++)
      {
         newFibonacci = oldFibonacci + olderFibonacci;
         olderFibonacci = oldFibonacci;
         oldFibonacci = newFibonacci;
      }

      return newFibonacci;

   }
}
