import java.util.ArrayList;

public class FastFibSequence implements Sequence
{
   private final int FIBONACCI_INDEX_START = 0;
   private final int FIRST_TWO_FIBONACCI_NUMBERS = 1;
   private int fibonacciIndexCounter = FIBONACCI_INDEX_START;
   private boolean longOverflowHappened = false;
   private ArrayList<Long> previousValues = new ArrayList<Long>();

   /**
    * Returns the next number in the fibonacci Sequence. This method utilizes
    * a fast recursive method as it stores the previous Fibonacci values at the
    * requested indexes.
    * <p>
    * This method will return Fibonacci numbers starting with 1. If the
    * Fibonacci number is greater than the maximum integer, thus resulting in
    * integer overflow, a FibonacciIntegerOverflow exception will be thrown.
    * <p>
    * This exception holds the overflown integer value as a long, which the
    * user can then acquire.
    * <p>
    * If this method reaches a value greater than the maximum long value,
    * thus resulting in long overflow, will throw a FibonacciLongOverflow
    * exception.
    *
    * @return Next integer Fibonacci number
    * @throws FibonacciIntegerOverflow Thrown when integer overflow occurs
    *                                  when calculating the next Fibonacci
    *                                  number. The exception object holds
    *                                  the value of the integer overflow.
    * @throws FibonacciLongOverflow    Thrown when long overflow occurs when
    *                                  calculating the next Fibonacci number.
    **/
   public int next() throws FibonacciIntegerOverflow, FibonacciLongOverflow
   {
      if (longOverflowHappened)
      {
         throw new FibonacciLongOverflow();
      }

      long thisFibonacci = fastRecursiveFibonacci(fibonacciIndexCounter);
      fibonacciIndexCounter++;
      previousValues.add(thisFibonacci);

      //If the value is negative, long overflow happened
      final int ZERO_FOR_NEGATIVE_CHECK = 0;
      if (thisFibonacci < ZERO_FOR_NEGATIVE_CHECK)
      {
         longOverflowHappened = true;
         throw new FibonacciLongOverflow();
      }
      else if (thisFibonacci > Integer.MAX_VALUE)
      {
         throw new FibonacciIntegerOverflow(thisFibonacci);
      }

      return (int) thisFibonacci;
   }

   /**
    * Returns the Fibonacci value at the requested index at maximized speeds.
    * This speed is achieved by storing the previous Fibonacci numbers
    * calculated in an ArrayList, and accessing them instead of recalculating
    * them at each index.
    *
    * The next index value is calculated by adding the 2 previous values, and
    * the first values are known to be {1, 1}. As the first 2 values are
    * known, the next values can be calculated.
    * @param fibonacciIndex The index of the requested Fibonacci number
    * @return long value of the Fibonacci at the requested index
    */
   private long fastRecursiveFibonacci(int fibonacciIndex)
   {
      final int INDEX_IN_ARRAY_OFFSET = 1;
      final int FIBONACCI_KNOWN_INDEX_VALUES = 1;

      if (fibonacciIndex <= FIBONACCI_KNOWN_INDEX_VALUES)
      {
         return FIRST_TWO_FIBONACCI_NUMBERS;
      }
      //If fibonacci number is stored in the previous values, return it.
      else if (fibonacciIndex < (previousValues.size() - INDEX_IN_ARRAY_OFFSET))
      {
         return previousValues.get(fibonacciIndex);
      }
      else //If calculated the first time, do normal recursion.
      {
         final int ONE_INDEX_BACK = 1;
         final int TWO_INDEX_BACK = 2;

         return fastRecursiveFibonacci(fibonacciIndex - ONE_INDEX_BACK) +
                fastRecursiveFibonacci(fibonacciIndex - TWO_INDEX_BACK);
      }
   }
}
