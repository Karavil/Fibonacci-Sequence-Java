public class FibSequence implements Sequence
{
   //Declare constants
   private final int FIBONACCI_INDEX_START = 0;
   private final int FIRST_TWO_FIBONACCI_NUMBERS = 1;

   //Declare instance variables
   private int fibonacciIndexCounter = FIBONACCI_INDEX_START;
   private boolean longOverflowHappened = false;

   /**
    * Returns the next number in the fibonacci Sequence. This method utilizes
    * a slow recursive method, such that it might take a long time if this
    * method is called multiples times.
    *
    * This method will return Fibonacci numbers starting with 1. If the
    * Fibonacci number is greater than the maximum integer, thus resulting in
    * integer overflow, a FibonacciIntegerOverflow exception will be thrown.
    *
    * This exception holds the overflown integer value as a long, which the
    * user can then acquire.
    *
    * If this method reaches a value greater than the maximum long value,
    * thus resulting in long overflow, will throw a FibonacciLongOverflow
    * exception.
    *
    * @return  Next integer Fibonacci number
    * @throws FibonacciIntegerOverflow Thrown when integer overflow occurs
    * when calculating the next Fibonacci number. The exception object holds
    * the value of the integer overflow.
    * @throws FibonacciLongOverflow Thrown when long overflow occurs when
    * calculating the next Fibonacci number.
    */
   public int next() throws FibonacciIntegerOverflow, FibonacciLongOverflow
   {
      if (longOverflowHappened)
      {
         throw new FibonacciLongOverflow();
      }

      long thisFibonacci = slowRecursiveFibonacci(fibonacciIndexCounter);
      fibonacciIndexCounter++;

      //If less than 0, long overflow happened as it should be increasing
      final int ZERO_FOR_NEGATIVE_CHECK = 0;
      if (thisFibonacci < ZERO_FOR_NEGATIVE_CHECK)
      {
         longOverflowHappened = true;
         throw new FibonacciLongOverflow();
      }
      else if (thisFibonacci > Integer.MAX_VALUE)
      {
         throw new FibonacciIntegerOverflow(thisFibonacci);
      }

      return (int) thisFibonacci;
   }

   /**
    * Returns the value of the Fibonacci number at the specified index. This
    * method is able to calculate these values by recursion, but is is much
    * more slower as it has to calculate all the values again at each index
    * as it is recursively called.
    *
    * The next index value is calculated by adding the 2 previous values, and
    * the first values are known to be {1, 1}. As the first 2 values are
    * known, the next values can be calculated.
    * @param fibonacciIndex Index of the requested Fibonacci value
    * @return long representation of the Fibonacci number at requested index
    */
   private long slowRecursiveFibonacci(int fibonacciIndex)
   {
      final int FIBONACCI_KNOWN_INDEX_VALUES = 1;
      if (fibonacciIndex <= FIBONACCI_KNOWN_INDEX_VALUES)
      {
         return FIRST_TWO_FIBONACCI_NUMBERS;
      }

      final int ONE_INDEX_BACK = 1;
      final int TWO_INDEX_BACK = 2;
      return slowRecursiveFibonacci(fibonacciIndex - ONE_INDEX_BACK) +
             slowRecursiveFibonacci(fibonacciIndex - TWO_INDEX_BACK);
   }
}
