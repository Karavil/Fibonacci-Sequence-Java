public class FibonacciSequenceOverflow extends ArithmeticException
{
   public FibonacciSequenceOverflow()
   {
      super();
   }

   public FibonacciSequenceOverflow(String message)
   {
      super(message);
   }
}

class FibonacciLongOverflow extends FibonacciSequenceOverflow
{
   public FibonacciLongOverflow()
   {
      super("ERROR: Fibonacci calculation has overflowed its long value.");
   }
}

class FibonacciIntegerOverflow extends FibonacciSequenceOverflow
{
   private long overflowValue;

   public FibonacciIntegerOverflow(long integerOverflowValue)
   {
      //super("ERROR: Fibonacci calculation has overflowed its long value.");
      this.overflowValue = integerOverflowValue;
   }

   public String getOverflowAsString()
   {
      return Long.toString(overflowValue);
   }

   public Long getOverflowAsLong()
   {
      return overflowValue;
   }
}
